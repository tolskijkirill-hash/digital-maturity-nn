from app.main import valid_inn
from app.questions import QUESTIONS,DIRECTIONS
from app.scoring import calculate,level_for

def test_inn():
    assert valid_inn('7707083893')
    assert not valid_inn('1234567890')
    assert not valid_inn('123')

def test_question_count_and_directions():
    assert len(QUESTIONS)==24
    assert len(DIRECTIONS)==8

def test_score_deterministic_and_na_ignored():
    answers={q['id']:'2' for q in QUESTIONS}
    a=calculate(answers)
    assert a==calculate(answers)
    assert a['overall'] is not None
    answers['q07']='na'
    b=calculate(answers)
    assert b['directions']['erp']['answered']==2

def test_levels():
    assert level_for(1.2)=='Начальный'
    assert level_for(3.7)=='Продвинутый'
