import csv,io,json,os,re,secrets
from pathlib import Path
from fastapi import FastAPI,Request,Form,HTTPException
from fastapi.responses import HTMLResponse,RedirectResponse,Response,StreamingResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.middleware.sessions import SessionMiddleware
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from .db import init_db,connect
from .questions import QUESTIONS,DIRECTIONS
from .scoring import calculate

app=FastAPI(title='Оценка цифровой зрелости',docs_url=None,redoc_url=None)
secret=os.getenv('APP_SECRET_KEY') or secrets.token_urlsafe(48)
app.add_middleware(SessionMiddleware,secret_key=secret,same_site='lax',https_only=False)
app.mount('/static',StaticFiles(directory='app/static'),name='static')
templates=Jinja2Templates(directory='app/templates')
ADMIN_USERNAME=os.getenv('ADMIN_USERNAME','admin')
ADMIN_PASSWORD=os.getenv('ADMIN_PASSWORD','change-this-password')
@app.on_event('startup')
def startup(): init_db()

def valid_inn(s):
    if not s.isdigit(): return False
    if len(s)==10:
        w=[2,4,10,3,5,9,4,6,8]
        return sum(int(s[i])*w[i] for i in range(9))%11%10==int(s[9])
    if len(s)==12:
        w1=[7,2,4,10,3,5,9,4,6,8,0];w2=[3,7,2,4,10,3,5,9,4,6,8,0]
        return sum(int(s[i])*w1[i] for i in range(11))%11%10==int(s[10]) and sum(int(s[i])*w2[i] for i in range(12))%11%10==int(s[11])
    return False

@app.get('/',response_class=HTMLResponse)
def index(request:Request):
    return templates.TemplateResponse('survey.html',{'request':request,'questions':QUESTIONS,'directions':DIRECTIONS})
@app.post('/submit')
async def submit(request:Request,company:str=Form(...),inn:str=Form(...),industry:str=Form(...),size:str=Form(...),municipality:str=Form(...),last_name:str=Form(...),first_name:str=Form(...),middle_name:str=Form(''),position:str=Form(...),phone:str=Form(...),email:str=Form(...)):
    required=[company,inn,industry,size,municipality,last_name,first_name,position,phone,email]
    if any(not x.strip() for x in required): raise HTTPException(422,'Заполните обязательные поля.')
    if not valid_inn(inn.strip()): raise HTTPException(422,'ИНН не прошёл проверку контрольных цифр; это не проверка реестра.')
    if not re.fullmatch(r'[^@\s]+@[^@\s]+\.[^@\s]+',email.strip()): raise HTTPException(422,'Проверьте электронную почту.')
    form=await request.form();answers={}
    for q in QUESTIONS:
        val=form.get(q['id'])
        if val is None: raise HTTPException(422,'Не заполнен обязательный вопрос: '+q['text'])
        if val not in [x[0] for x in q['options']]: raise HTTPException(422,'Недопустимый вариант ответа.')
        answers[q['id']]=val
    if form.get('consent')!='yes': raise HTTPException(422,'Подтвердите ознакомление с документами о персональных данных.')
    result=calculate(answers)
    with connect() as c:
        cur=c.execute('''INSERT INTO submissions(company,inn,industry,size,municipality,last_name,first_name,middle_name,position,phone,email,answers_json,result_json,status)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',(company.strip(),inn.strip(),industry.strip(),size.strip(),municipality.strip(),last_name.strip(),first_name.strip(),middle_name.strip(),position.strip(),phone.strip(),email.strip(),json.dumps(answers,ensure_ascii=False),json.dumps(result,ensure_ascii=False),'result_calculated'))
        sid=cur.lastrowid
    return RedirectResponse(f'/result/{sid}',status_code=303)
@app.get('/result/{sid}',response_class=HTMLResponse)
def result(request:Request,sid:int):
    with connect() as c: row=c.execute('SELECT * FROM submissions WHERE id=?',(sid,)).fetchone()
    if not row: raise HTTPException(404,'Результат не найден')
    return templates.TemplateResponse('result.html',{'request':request,'row':row,'result':json.loads(row['result_json'])})
@app.get('/result/{sid}/pdf')
def pdf(sid:int):
    with connect() as c: row=c.execute('SELECT * FROM submissions WHERE id=?',(sid,)).fetchone()
    if not row: raise HTTPException(404,'Результат не найден')
    res=json.loads(row['result_json']);buf=io.BytesIO();doc=SimpleDocTemplate(buf,pagesize=A4,rightMargin=40,leftMargin=40,topMargin=40,bottomMargin=40)
    styles=getSampleStyleSheet();font='Helvetica'
    for fp in ['/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf','C:/Windows/Fonts/arial.ttf','/Library/Fonts/Arial.ttf']:
        if Path(fp).exists():
            try: pdfmetrics.registerFont(TTFont('CyrillicFont',fp));font='CyrillicFont';break
            except Exception: pass
    title=ParagraphStyle('RuTitle',parent=styles['Title'],fontName=font,fontSize=16,leading=21,textColor=colors.HexColor('#12345a'))
    body=ParagraphStyle('RuBody',parent=styles['BodyText'],fontName=font,fontSize=9,leading=13)
    story=[Paragraph('Предварительный отчёт об оценке цифровой зрелости',title),Spacer(1,12),Paragraph('Предприятие: '+row['company'],body),Paragraph('ИНН: '+row['inn']+' · Дата: '+row['created_at'],body),Paragraph('Индекс: '+str(res['overall'])+' из 5 · Уровень: '+res['level'],body),Spacer(1,12)]
    data=[['Направление','Индекс','Уровень']]
    for v in res['directions'].values(): data.append([v['name'],str(v['index'] if v['index'] is not None else '—'),v['level']])
    t=Table(data,colWidths=[265,65,140],repeatRows=1);t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#12345a')),('TEXTCOLOR',(0,0),(-1,0),colors.white),('FONTNAME',(0,0),(-1,-1),font),('FONTSIZE',(0,0),(-1,-1),8),('GRID',(0,0),(-1,-1),.4,colors.HexColor('#dce5ee')),('VALIGN',(0,0),(-1,-1),'TOP'),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,colors.HexColor('#f3f6fa')]),('LEFTPADDING',(0,0),(-1,-1),7),('TOPPADDING',(0,0),(-1,-1),7),('BOTTOMPADDING',(0,0),(-1,-1),7)]))
    story += [t,Spacer(1,12),Paragraph('Методика предварительная и требует утверждения. Результат не является официальным заключением и не гарантирует получение государственной поддержки.',body)]
    doc.build(story)
    return Response(buf.getvalue(),media_type='application/pdf',headers={'Content-Disposition':f'attachment; filename="report-{sid}.pdf"'})

@app.get('/admin/login',response_class=HTMLResponse)
def login_page(request:Request): return templates.TemplateResponse('login.html',{'request':request,'error':None})
@app.post('/admin/login',response_class=HTMLResponse)
def login(request:Request,username:str=Form(...),password:str=Form(...)):
    if secrets.compare_digest(username,ADMIN_USERNAME) and secrets.compare_digest(password,ADMIN_PASSWORD) and ADMIN_PASSWORD!='change-this-password':
        request.session['admin']=True;return RedirectResponse('/admin',status_code=303)
    return templates.TemplateResponse('login.html',{'request':request,'error':'Не удалось войти. Проверьте данные и настройку пароля.'},status_code=401)
@app.post('/admin/logout')
def logout(request:Request): request.session.clear();return RedirectResponse('/admin/login',status_code=303)
@app.get('/admin',response_class=HTMLResponse)
def admin(request:Request,q:str=''):
    if not request.session.get('admin'): return RedirectResponse('/admin/login',status_code=303)
    with connect() as c:
        if q.strip():
            p='%'+q.strip()+'%';rows=c.execute('SELECT id,created_at,company,inn,municipality,status,result_json FROM submissions WHERE company LIKE ? OR inn LIKE ? ORDER BY id DESC LIMIT 500',(p,p)).fetchall()
        else: rows=c.execute('SELECT id,created_at,company,inn,municipality,status,result_json FROM submissions ORDER BY id DESC LIMIT 500').fetchall()
    data=[]
    for r in rows:
        d=dict(r);d['result']=json.loads(d.pop('result_json'));data.append(d)
    return templates.TemplateResponse('admin.html',{'request':request,'rows':data,'q':q})
@app.get('/admin/submission/{sid}',response_class=HTMLResponse)
def admin_detail(request:Request,sid:int):
    if not request.session.get('admin'): return RedirectResponse('/admin/login',status_code=303)
    with connect() as c: row=c.execute('SELECT * FROM submissions WHERE id=?',(sid,)).fetchone()
    if not row: raise HTTPException(404,'Анкета не найдена')
    answers=json.loads(row['answers_json']);res=json.loads(row['result_json']);text={}
    for q in QUESTIONS: text[q['id']]=next((label for code,label in q['options'] if code==answers.get(q['id'])), 'Нет ответа')
    return templates.TemplateResponse('submission.html',{'request':request,'row':row,'answers':answers,'answer_text':text,'questions':QUESTIONS,'result':res})
@app.get('/admin/export.csv')
def export(request:Request):
    if not request.session.get('admin'): return RedirectResponse('/admin/login',status_code=303)
    with connect() as c: rows=c.execute('SELECT * FROM submissions ORDER BY id DESC').fetchall()
    out=io.StringIO();w=csv.writer(out,delimiter=';')
    w.writerow(['ID','Дата','Предприятие','ИНН','Отрасль','Размер','Муниципалитет','Фамилия','Имя','Отчество','Должность','Телефон','Email','Статус','Индекс','Уровень'])
    for r in rows:
        x=json.loads(r['result_json']);vals=[r['id'],r['created_at'],r['company'],r['inn'],r['industry'],r['size'],r['municipality'],r['last_name'],r['first_name'],r['middle_name'],r['position'],r['phone'],r['email'],r['status'],x['overall'],x['level']]
        w.writerow([("'"+str(v)) if isinstance(v,str) and v.startswith(('=','+','-','@','\t','\r')) else v for v in vals])
    return StreamingResponse(iter([out.getvalue().encode('utf-8-sig')]),media_type='text/csv; charset=utf-8',headers={'Content-Disposition':'attachment; filename=submissions.csv'})
@app.get('/health')
def health(): return {'status':'ok','mode':'development','methodology':'preliminary-0.1'}
