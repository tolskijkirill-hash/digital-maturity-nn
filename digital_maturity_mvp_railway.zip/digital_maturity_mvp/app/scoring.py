from .questions import QUESTIONS,DIRECTIONS
LEVELS=[(1.0,1.79,'Начальный'),(1.8,2.59,'Базовый'),(2.6,3.39,'Развивающийся'),(3.4,4.19,'Продвинутый'),(4.2,5.0,'Высокий')]
def level_for(x):
    for lo,hi,label in LEVELS:
        if lo <= x <= hi: return label
    return 'Недостаточно данных'
def calculate(answers):
    out={}
    for key,label in DIRECTIONS:
        scores=[]
        for q in QUESTIONS:
            if q['direction'] != key: continue
            v=answers.get(q['id'])
            if v is None or v=='na': continue
            try: n=int(v)
            except (ValueError,TypeError): continue
            if 0 <= n <= 3: scores.append(n)
        if scores:
            idx=round(1+4*(sum(scores)/len(scores))/3,2)
            out[key]={'name':label,'index':idx,'level':level_for(idx),'answered':len(scores),'total':sum(1 for q in QUESTIONS if q['direction']==key)}
        else: out[key]={'name':label,'index':None,'level':'Недостаточно данных','answered':0,'total':sum(1 for q in QUESTIONS if q['direction']==key)}
    vals=[x['index'] for x in out.values() if x['index'] is not None]
    overall=round(sum(vals)/len(vals),2) if vals else None
    return {'overall':overall,'level':level_for(overall) if overall is not None else 'Недостаточно данных','directions':out,'method_version':'preliminary-0.1'}
