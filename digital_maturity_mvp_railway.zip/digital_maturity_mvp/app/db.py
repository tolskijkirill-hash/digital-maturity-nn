import os,sqlite3
from pathlib import Path
DB_PATH=os.getenv('DATABASE_PATH','./data/app.db')
def connect():
    Path(DB_PATH).parent.mkdir(parents=True,exist_ok=True)
    c=sqlite3.connect(DB_PATH,timeout=10);c.row_factory=sqlite3.Row;c.execute('PRAGMA foreign_keys=ON');return c
def init_db():
    with connect() as c:
        c.executescript('''CREATE TABLE IF NOT EXISTS submissions(
        id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        company TEXT NOT NULL,inn TEXT NOT NULL,industry TEXT NOT NULL,size TEXT NOT NULL,municipality TEXT NOT NULL,
        last_name TEXT NOT NULL,first_name TEXT NOT NULL,middle_name TEXT,position TEXT NOT NULL,phone TEXT NOT NULL,email TEXT NOT NULL,
        answers_json TEXT NOT NULL,result_json TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'result_calculated');
        CREATE INDEX IF NOT EXISTS idx_inn ON submissions(inn);
        CREATE INDEX IF NOT EXISTS idx_created ON submissions(created_at);''')
